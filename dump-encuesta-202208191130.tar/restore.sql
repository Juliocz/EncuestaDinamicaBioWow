--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.22
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE encuesta;
--
-- Name: encuesta; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE encuesta WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE encuesta OWNER TO postgres;

\connect encuesta

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: encuesta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.encuesta (
    id_usuario integer,
    idencuesta integer NOT NULL,
    nombre_enc character varying,
    idun integer NOT NULL,
    estado integer DEFAULT 0 NOT NULL,
    creado timestamp without time zone DEFAULT now() NOT NULL,
    modificado timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.encuesta OWNER TO postgres;

--
-- Name: encuesta_idencuesta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.encuesta_idencuesta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encuesta_idencuesta_seq OWNER TO postgres;

--
-- Name: encuesta_idencuesta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.encuesta_idencuesta_seq OWNED BY public.encuesta.idencuesta;


--
-- Name: opcion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opcion (
    idopcion integer NOT NULL,
    idpregunta integer NOT NULL,
    descripcion character varying,
    orden integer DEFAULT 0 NOT NULL,
    estado integer DEFAULT 0 NOT NULL,
    url_iconr character varying,
    url_iconanimr character varying,
    creado timestamp without time zone DEFAULT now() NOT NULL,
    modificado timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.opcion OWNER TO postgres;

--
-- Name: opcion_idopcion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.opcion_idopcion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.opcion_idopcion_seq OWNER TO postgres;

--
-- Name: opcion_idopcion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.opcion_idopcion_seq OWNED BY public.opcion.idopcion;


--
-- Name: pregunta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pregunta (
    idpregunta integer NOT NULL,
    idencuesta integer NOT NULL,
    pregunta character varying,
    estado integer DEFAULT 0 NOT NULL,
    tipo character varying,
    creado timestamp without time zone DEFAULT now() NOT NULL,
    modificado timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.pregunta OWNER TO postgres;

--
-- Name: pregunta_idpregunta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pregunta_idpregunta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pregunta_idpregunta_seq OWNER TO postgres;

--
-- Name: pregunta_idpregunta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pregunta_idpregunta_seq OWNED BY public.pregunta.idpregunta;


--
-- Name: respuesta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.respuesta (
    idresp integer NOT NULL,
    idencuesta integer NOT NULL,
    idpregunta integer NOT NULL,
    idopcion integer NOT NULL,
    creado timestamp without time zone DEFAULT now() NOT NULL,
    modificado timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.respuesta OWNER TO postgres;

--
-- Name: respuesta_idresp_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.respuesta_idresp_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.respuesta_idresp_seq OWNER TO postgres;

--
-- Name: respuesta_idresp_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.respuesta_idresp_seq OWNED BY public.respuesta.idresp;


--
-- Name: un_negocio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.un_negocio (
    idun integer NOT NULL,
    nombre character varying,
    direccion character varying,
    telefono integer,
    estado integer DEFAULT 0 NOT NULL,
    codigo character varying(32),
    creado timestamp without time zone DEFAULT now() NOT NULL,
    modificado timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.un_negocio OWNER TO postgres;

--
-- Name: un_negocio_idun_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.un_negocio_idun_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.un_negocio_idun_seq OWNER TO postgres;

--
-- Name: un_negocio_idun_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.un_negocio_idun_seq OWNED BY public.un_negocio.idun;


--
-- Name: encuesta idencuesta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encuesta ALTER COLUMN idencuesta SET DEFAULT nextval('public.encuesta_idencuesta_seq'::regclass);


--
-- Name: opcion idopcion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcion ALTER COLUMN idopcion SET DEFAULT nextval('public.opcion_idopcion_seq'::regclass);


--
-- Name: pregunta idpregunta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pregunta ALTER COLUMN idpregunta SET DEFAULT nextval('public.pregunta_idpregunta_seq'::regclass);


--
-- Name: respuesta idresp; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuesta ALTER COLUMN idresp SET DEFAULT nextval('public.respuesta_idresp_seq'::regclass);


--
-- Name: un_negocio idun; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.un_negocio ALTER COLUMN idun SET DEFAULT nextval('public.un_negocio_idun_seq'::regclass);


--
-- Data for Name: encuesta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.encuesta (id_usuario, idencuesta, nombre_enc, idun, estado, creado, modificado) FROM stdin;
\.
COPY public.encuesta (id_usuario, idencuesta, nombre_enc, idun, estado, creado, modificado) FROM '$$PATH$$/2850.dat';

--
-- Data for Name: opcion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opcion (idopcion, idpregunta, descripcion, orden, estado, url_iconr, url_iconanimr, creado, modificado) FROM stdin;
\.
COPY public.opcion (idopcion, idpregunta, descripcion, orden, estado, url_iconr, url_iconanimr, creado, modificado) FROM '$$PATH$$/2856.dat';

--
-- Data for Name: pregunta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pregunta (idpregunta, idencuesta, pregunta, estado, tipo, creado, modificado) FROM stdin;
\.
COPY public.pregunta (idpregunta, idencuesta, pregunta, estado, tipo, creado, modificado) FROM '$$PATH$$/2854.dat';

--
-- Data for Name: respuesta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.respuesta (idresp, idencuesta, idpregunta, idopcion, creado, modificado) FROM stdin;
\.
COPY public.respuesta (idresp, idencuesta, idpregunta, idopcion, creado, modificado) FROM '$$PATH$$/2858.dat';

--
-- Data for Name: un_negocio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.un_negocio (idun, nombre, direccion, telefono, estado, codigo, creado, modificado) FROM stdin;
\.
COPY public.un_negocio (idun, nombre, direccion, telefono, estado, codigo, creado, modificado) FROM '$$PATH$$/2852.dat';

--
-- Name: encuesta_idencuesta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encuesta_idencuesta_seq', 20, true);


--
-- Name: opcion_idopcion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.opcion_idopcion_seq', 32, true);


--
-- Name: pregunta_idpregunta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pregunta_idpregunta_seq', 12, true);


--
-- Name: respuesta_idresp_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.respuesta_idresp_seq', 23, true);


--
-- Name: un_negocio_idun_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.un_negocio_idun_seq', 1, false);


--
-- Name: encuesta encuesta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.encuesta
    ADD CONSTRAINT encuesta_pkey PRIMARY KEY (idencuesta);


--
-- Name: opcion opcion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opcion
    ADD CONSTRAINT opcion_pkey PRIMARY KEY (idopcion);


--
-- Name: pregunta pregunta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pregunta
    ADD CONSTRAINT pregunta_pkey PRIMARY KEY (idpregunta);


--
-- Name: respuesta respuesta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuesta
    ADD CONSTRAINT respuesta_pkey PRIMARY KEY (idresp);


--
-- Name: un_negocio un_negocio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.un_negocio
    ADD CONSTRAINT un_negocio_pkey PRIMARY KEY (idun);


--
-- PostgreSQL database dump complete
--

